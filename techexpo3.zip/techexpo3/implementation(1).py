from flask import Flask, render_template, Response, request, jsonify
import cv2
from cvzone.HandTrackingModule import HandDetector
import numpy as np
import mediapipe as mp
import math
import time
import os
import re

app = Flask(__name__)

offset = 50
imgSize = 300
folder = "captured_images"
os.makedirs(folder, exist_ok=True)

cap = cv2.VideoCapture(0)
camera = 'Start Webcam'
matched_labels = []  # List to store matched labels

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.5)
mp_draw = mp.solutions.drawing_utils
detector = HandDetector(maxHands=1, detectionCon=0.8)

# Function to extract hand landmarks from an image
def extract_hand_landmarks(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return None
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    result = hands.process(image_rgb)
    if result.multi_hand_landmarks:
        landmarks = result.multi_hand_landmarks[0]
        return np.array([[lm.x, lm.y, lm.z] for lm in landmarks.landmark]).flatten()
    return None

# Function to calculate similarity between two landmark sets
def calculate_similarity(landmarks1, landmarks2):
    return np.linalg.norm(landmarks1 - landmarks2)

# Function to match input image with stored images in a folder
def match_image(input_image):
    input_landmarks = extract_hand_landmarks(input_image)
    if input_landmarks is None:
        return None

    closest_match = None
    closest_distance = float('inf')
    matched_file = None
    comparison_folder = "check_image"

    # Iterate over all images in the folder
    for file_name in os.listdir(comparison_folder):
        file_path = os.path.join(comparison_folder, file_name)
        comparison_landmarks = extract_hand_landmarks(file_path)

        if comparison_landmarks is not None:
            distance = calculate_similarity(input_landmarks, comparison_landmarks)
            if distance < closest_distance:
                closest_distance = distance
                matched_file = file_name

    if matched_file:
        matched_label = os.path.splitext(matched_file)[0]
        cleaned_string = re.sub(r'[ \[\] (){}0-9]', '', matched_label)
        matched_labels.append(cleaned_string)  # Store matched label
        return cleaned_string
    return None

# Function to capture images and match
def capture_images_and_match():
    success, img = cap.read()
    hands_list, _ = detector.findHands(img, draw=False)

    if hands_list:
        hand = hands_list[0]
        x, y, w, h = hand['bbox']

        imgWhite = np.ones((imgSize, imgSize, 3), np.uint8) * 255
        x1, y1 = max(0, x - offset), max(0, y - offset)
        x2, y2 = x + w + offset, y + h + offset
        imgCrop = img[y1:y2, x1:x2]

        if imgCrop.size == 0:
            return

        aspectRatio = h / w
        if aspectRatio > 1:
            k = imgSize / h
            wCal = math.ceil(k * w)
            imgResize = cv2.resize(imgCrop, (wCal, imgSize))
            wGap = math.ceil((imgSize - wCal) / 2)
            imgWhite[:, wGap:wCal + wGap] = imgResize
        else:
            k = imgSize / w
            hCal = math.ceil(k * h)
            imgResize = cv2.resize(imgCrop, (imgSize, hCal))
            hGap = math.ceil((imgSize - hCal) / 2)
            imgWhite[hGap:hCal + hGap, :] = imgResize

        timestamp = str(time.time())
        captured_image_path = f"{folder}/Image_{timestamp}.jpg"
        cv2.imwrite(captured_image_path, imgWhite)

        # Call match_image function with the captured image
        matched_label = match_image(captured_image_path)
        return matched_label

# Function to handle the webcam video feed
def wait():
    last_called_time = time.time()
    interval = 3  # Interval in seconds

    while True:
        current_time = time.time()
        success, img = cap.read()

        if current_time - last_called_time >= interval:
            capture_images_and_match()
            last_called_time = current_time

        if not success:
            break
        else:
            success, buffer = cv2.imencode('.jpg', img)
            img = buffer.tobytes()
        yield (b'--img\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + img + b'\r\n')

# Flask Routes
@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template("index.html", camera=camera)

@app.route('/toggle', methods=['POST'])
def toggle():
    global camera
    if camera == 'Start Webcam':
        wait()
        camera = 'Stop Webcam'
    else:
        camera = 'Start Webcam'
    return render_template('index.html', camera=camera)

@app.route("/video_feed1")
def video_feed1():
    return Response(wait(), mimetype='multipart/x-mixed-replace; boundary=img')

# # API Endpoint to return the matched label
# @app.route("/match-result", methods=["GET"])
# def match_result():
#     if matched_labels:
#         return jsonify({"matched_label": matched_labels[-1]})  # Return latest match
#     return jsonify({"message": "No match found"})

# Store match result in memory
match_data = {"message": "No match found"}  # Default message

@app.route('/match-result', methods=['GET'])
def get_match_result():
    """Returns the latest match result."""
    return jsonify(match_data)

@app.route('/match-result', methods=['POST'])
def update_match_result():
    """Updates the match result dynamically."""
    global match_data
    match_data = request.json  # Receive JSON data from the client
    return jsonify({"status": "success", "message": "Match result updated!"})


if __name__ == '__main__':
    app.run(debug=True)
