// document.addEventListener("DOMContentLoaded", function () {
//     const islBtn = document.getElementById("islBtn");
//     const hindiBtn = document.getElementById("hindiBtn");

//     islBtn.addEventListener("click", function () {
//         showDialog("Enter ISL text:");
//     });

//     hindiBtn.addEventListener("click", function () {
//         showLanguageOptions();
//     });

//     function showDialog(message) {
//         let dialog = document.createElement("div");
//         dialog.className = "dialog-box";
//         dialog.innerHTML = `
//             <p>${message}</p>
//             <input type="text" placeholder="Type here...">
//             <br>
//             <button onclick="this.parentNode.remove()">Close</button>
//         `;
//         document.body.appendChild(dialog);
//     }

//     function showLanguageOptions() {
//         let dialog = document.createElement("div");
//         dialog.className = "dialog-box";
//         dialog.innerHTML = `
//             <p>Select Language:</p>
//             <select>
//                 <option>Gujarati</option>
//                 <option>Marathi</option>
//                 <option>Tamil</option>
//                 <option>Telugu</option>
//                 <option>English</option>
//             </select>
//             <br>
//             <button onclick="this.parentNode.remove()">Close</button>
//         `;
//         document.body.appendChild(dialog);
//     }
// });

function openDialog(dialogId) {
  document.getElementById(dialogId).style.display = "block";
}

function closeDialog(dialogId) {
  document.getElementById(dialogId).style.display = "none";
}

function changeLanguage(language) {
  document.getElementById('selectedLanguage').innerText = language;
  closeDialog('languageDialog');
  fetchData();  // Refresh translation on language change
}


// function changeLanguage(language) {
//   document.getElementById('selectedLanguage').innerText = language;
//   closeDialog('languageDialog');
// }

const cameraContainer = document.querySelector(".camera-window");
const toggleButton = document.getElementById("toggle-camera");
let isCameraOn = false;
let videoElement = null;

toggleButton.addEventListener("click", () => {
    if (!isCameraOn) {
        // Create and append the image element dynamically
        videoElement = document.createElement("img");
        videoElement.id = "camera-feed";
        videoElement.src = "/video_feed1"; // Replace with actual video feed URL
        videoElement.alt = "Camera Feed";
        cameraContainer.insertBefore(videoElement, toggleButton);
        
        toggleButton.textContent = "Stop Camera";  // Update button text
        toggleButton.style.background = "#dc3545";  // Change button color
        isCameraOn = true;
    } else {
        // Remove the image element
        if (videoElement) {
            videoElement.remove();
            videoElement = null;
        }

        toggleButton.textContent = "Start Camera";  // Update button text
        toggleButton.style.background = "#28a745";  // Change button color
        isCameraOn = false;
    }
});


// const videoElement = document.getElementById("camera-feed");
// const toggleButton = document.getElementById("toggle-camera");
// let isCameraOn = false;

// toggleButton.addEventListener("click", () => {
//     if (!isCameraOn) {
//         // Show the camera feed (this could be a static image or video stream URL)
//         videoElement.style.display = "block";  
//         toggleButton.textContent = "Stop Camera";  // Update button text
//         toggleButton.style.background = "#dc3545";  // Change button color
//         isCameraOn = true;
//     } else {
//         // Hide the camera feed
//         videoElement.style.display = "none";
//         toggleButton.textContent = "Start Camera";  // Update button text
//         toggleButton.style.background = "#28a745";  // Change button color
//         isCameraOn = false;
//     }
// });



// async function fetchData() {
//     const outputBox = document.querySelector('.output-box');
//     outputBox.innerHTML = "Fetching data..."; // Show loading text

//     try {
//         let response = await fetch("http://127.0.0.1:5500/testing/index.html"); // Example API
//         if (!response.ok) {
//             throw new Error("Network response was not ok");
//         }
        
//         let data = await response.json();
//         outputBox.innerHTML = `${data.matched_label}`;
//         console.log(data);
//     } catch (error) {
//         outputBox.innerHTML = `<span style="color: red;">Error: ${error.message}</span>`;
//     }
// }

// setInterval(fetchData, 3000);

// // Call function immediately when script loads
// fetchData();

// async function fetchData() {
//     const outputBox = document.querySelector('.text-area');
//     outputBox.innerHTML = "Fetching data...";
  
//     try {
//       const response = await fetch("http://127.0.0.1:5000/match-result"); // Correct URL
//       if (!response.ok) {
//         throw new Error(`Network response was not ok: ${response.status}`); // Include status
//       }
  
//       const data = await response.json(); // Now correctly parses JSON
//       outputBox.innerHTML = `${data.matched_label}`;
//       console.log(data);
//     } catch (error) {
//       outputBox.innerHTML = `<span style="color: red;">Error: ${error.message}</span>`;
//       console.error("Fetch Error:", error); // Log to console for debugging
//     }
//   }
  
//   setInterval(fetchData, 3000);
//   fetchData(); // Call immediately


async function fetchData() {
  const outputBox = document.querySelector('.text-area');
  const selectedLang = document.getElementById('selectedLanguage').innerText.toLowerCase();
  const languageCode = getLanguageCode(selectedLang);  // Convert name to API-supported code

  // outputBox.innerHTML = "Fetching data...";

  try {
      const response = await fetch(`http://127.0.0.1:5000/match-result?lang=${languageCode}`);
      if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
      }

      const data = await response.json();
      outputBox.innerHTML = `${data.translated}`;
  } catch (error) {
      outputBox.innerHTML = `<span style="color: red;">Error: ${error.message}</span>`;
      console.error("Fetch Error:", error);
  }
}

// Function to convert language names to API-supported codes
function getLanguageCode(lang) {
  const languageMap = {
      "english": "en",
      "hindi": "hi",
      "gujarati": "gu",
      "marathi": "mr",
      "tamil": "ta",
      "telugu": "te",
      "bengali": "bn",
      "malayalam": "ml",
      "kannada": "kn",
      "punjabi": "pa"
  };
  return languageMap[lang] || "en";  // Default to English if not found
}

// Update fetch interval
setInterval(fetchData, 3000);
fetchData();

