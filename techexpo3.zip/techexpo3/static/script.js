document.addEventListener("DOMContentLoaded", function () {
    const islBtn = document.getElementById("islBtn");
    const hindiBtn = document.getElementById("hindiBtn");

    islBtn.addEventListener("click", function () {
        showDialog("Enter ISL text:");
    });

    hindiBtn.addEventListener("click", function () {
        showLanguageOptions();
    });

    function showDialog(message) {
        let dialog = document.createElement("div");
        dialog.className = "dialog-box";
        dialog.innerHTML = `
            <p>${message}</p>
            <input type="text" placeholder="Type here...">
            <br>
            <button onclick="this.parentNode.remove()">Close</button>
        `;
        document.body.appendChild(dialog);
    }

    function showLanguageOptions() {
        let dialog = document.createElement("div");
        dialog.className = "dialog-box";
        dialog.innerHTML = `
            <p>Select Language:</p>
            <select>
                <option>Gujarati</option>
                <option>Marathi</option>
                <option>Tamil</option>
                <option>Telugu</option>
                <option>English</option>
            </select>
            <br>
            <button onclick="this.parentNode.remove()">Close</button>
        `;
        document.body.appendChild(dialog);
    }
});

const videoElement = document.getElementById("camera-feed");
const toggleButton = document.getElementById("toggle-camera");
let isCameraOn = false;

toggleButton.addEventListener("click", () => {
    if (!isCameraOn) {
        // Show the camera feed (this could be a static image or video stream URL)
        videoElement.style.display = "block";  
        toggleButton.textContent = "Stop Camera";  // Update button text
        toggleButton.style.background = "#dc3545";  // Change button color
        isCameraOn = true;
    } else {
        // Hide the camera feed
        videoElement.style.display = "none";
        toggleButton.textContent = "Start Camera";  // Update button text
        toggleButton.style.background = "#28a745";  // Change button color
        isCameraOn = false;
    }
});



// async function fetchData() {
//     const outputBox = document.querySelector('.output-box');
//     outputBox.innerHTML = "Fetching data..."; // Show loading text

//     // try {
//     //     let response = await fetch("http://127.0.0.1:5000/match-result"); // Example API
//     //     if (!response.ok) {
//     //         throw new Error("Network response was not ok");
//     //     }
        
//     //     let data = await response.json();
//     //     outputBox.innerHTML = `${data.message}`;
//     // } catch (error) {
//     //     outputBox.innerHTML = `<span style="color: red;">Error: ${error.message}</span>`;
//     // }
// }

// setInterval(fetchData, 3000);

// Call function immediately when script loads
// fetchData();

// let previousContent = '';

// // Function to fetch the text file and display its content
// function fetchFileContent() {
//     fetch('../example.txt')
//     .then(response => {
//         if (!response.ok) {
//             throw new Error(`HTTP error! Status: ${response.status}`);
//         }
//         return response.text();
//     })
//         .then(data => {
//             if (data !== previousContent) {
//                 // document.getElementById('fileContent').textContent = data;
//                 // previousContent = data;
//                 console.log(data);
//             }
//         })
//         .catch(error => {
//             console.error('Error fetching the file:', error);
//         });
// }

// // Call the function when the page loads
// document.addEventListener('DOMContentLoaded', fetchFileContent);

// // Check for file updates every 5 seconds
// setInterval(fetchFileContent, 5000);





