from flask import Flask, render_template, Response, request, jsonify  
from flask_cors import CORS 
import cv2
from cvzone.HandTrackingModule import HandDetector
import numpy as np
import mediapipe as mp
import math
import time
import os
import re
import threading

import requests

TRANSLATION_API_URL = "https://api.mymemory.translated.net/get"

app = Flask(__name__)
CORS(app)

offset = 50
imgSize = 300
folder = "captured_images"
comparison_folder = "check_image"

# Ensure required folders exist
os.makedirs(folder, exist_ok=True)
os.makedirs(comparison_folder, exist_ok=True)

cap = cv2.VideoCapture(0)
camera_status = 'Start Webcam'
matched_labels = []  # List to store matched labels

# Initialize MediaPipe Hands
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.5)
mp_draw = mp.solutions.drawing_utils
detector = HandDetector(maxHands=1, detectionCon=0.8)

# Function to extract hand landmarks from an image
def extract_hand_landmarks(image_path):
    image = cv2.imread(image_path)
    if image is None:
        # print(f"Error: Unable to read image {image_path}")
        return None
    
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    result = hands.process(image_rgb)

    if result.multi_hand_landmarks:
        landmarks = result.multi_hand_landmarks[0]
        return np.array([[lm.x, lm.y, lm.z] for lm in landmarks.landmark]).flatten()
    
    # print(f"No hand detected in image: {image_path}")
    return None

# Function to calculate similarity between two landmark sets
def calculate_similarity(landmarks1, landmarks2):
    if landmarks1.shape != landmarks2.shape:
        return float('inf')  # Return a large value for non-matching sizes
    return np.linalg.norm(landmarks1 - landmarks2)

# Function to match input image with stored images in a folder
def match_image(input_image):
    input_landmarks = extract_hand_landmarks(input_image)
    if input_landmarks is None:
        return None

    closest_match = None
    closest_distance = float('inf')
    matched_file = None

    # Iterate over all images in the comparison folder
    for file_name in os.listdir(comparison_folder):
        file_path = os.path.join(comparison_folder, file_name)
        comparison_landmarks = extract_hand_landmarks(file_path)

        if comparison_landmarks is not None:
            distance = calculate_similarity(input_landmarks, comparison_landmarks)
            # print(f"Comparing {file_name}, Distance: {distance}")
            if distance < closest_distance:
                closest_distance = distance
                matched_file = file_name

    if matched_file:
        matched_label = os.path.splitext(matched_file)[0]
        cleaned_label = re.sub(r'[ \[\] (){}0-9]', '', matched_label)
        matched_labels.append(cleaned_label)  # Store matched label
        # print(f"Matched: {cleaned_label}")
        # Open the file in append mode ('a')
        with open("example.txt", "a") as file:
            file.write(cleaned_label+" ")

            

        return cleaned_label

    return None

# Function to capture images and match
def capture_images_and_match():
    success, img = cap.read()
    if not success:
        # print("Error: Failed to capture image from webcam")
        return None

    hands_list, _ = detector.findHands(img, draw=False)
    if not hands_list:
        # print("No hands detected in the frame")
        return None

    hand = hands_list[0]
    x, y, w, h = hand['bbox']

    imgWhite = np.ones((imgSize, imgSize, 3), np.uint8) * 255
    x1, y1 = max(0, x - offset), max(0, y - offset)
    x2, y2 = x + w + offset, y + h + offset
    imgCrop = img[y1:y2, x1:x2]

    if imgCrop.size == 0:
        # print("Invalid cropped image")
        return None

    aspectRatio = h / w
    if aspectRatio > 1:
        k = imgSize / h
        wCal = math.ceil(k * w)
        imgResize = cv2.resize(imgCrop, (wCal, imgSize))
        wGap = math.ceil((imgSize - wCal) / 2)
        imgWhite[:, wGap:wCal + wGap] = imgResize
    else:
        k = imgSize / w
        hCal = math.ceil(k * h)
        imgResize = cv2.resize(imgCrop, (imgSize, hCal))
        hGap = math.ceil((imgSize - hCal) / 2)
        imgWhite[hGap:hCal + hGap, :] = imgResize

    timestamp = str(time.time())
    captured_image_path = f"{folder}/Image_{timestamp}.jpg"
    cv2.imwrite(captured_image_path, imgWhite)

    # Match the captured image
    matched_label = match_image(captured_image_path)
    return matched_label

# Function to handle the webcam video feed
def video_feed():
    last_called_time = time.time()
    interval = 3  # Interval in seconds

    while True:
        success, img = cap.read()
        if not success:
            break

        current_time = time.time()
        if current_time - last_called_time >= interval:
            matched_label = capture_images_and_match()
            if matched_label:
                global match_data
                match_data = {"matched_label": matched_label}
            last_called_time = current_time

        success, buffer = cv2.imencode('.jpg', img)
        img = buffer.tobytes()
        yield (b'--img\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + img + b'\r\n')

# Flask Routes
@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template("index.html", camera_status=camera_status)

@app.route('/toggle', methods=['POST'])
def toggle():
    global camera_status
    if camera_status == 'Start Webcam':
        threading.Thread(target=video_feed, daemon=True).start()
        camera_status = 'Stop Webcam'
    else:
        camera_status = 'Start Webcam'
    return render_template('index.html', camera_status=camera_status)

@app.route("/video_feed1")
def video_feed1():
    return Response(video_feed(), mimetype='multipart/x-mixed-replace; boundary=img')

# Store match result in memory
match_data = {"message": "No match found"}  # Default message

# @app.route('/match-result', methods=['GET'])
# def get_match_result():
#     """Returns the latest match result."""
#     return jsonify(match_data)

@app.route('/match-result', methods=['GET'])
def get_match_result():
    """Returns the latest match result with translation."""
    selected_language = request.args.get("lang", "en")  # Default to English
    
    original_text = match_data.get("matched_label", "No match found")
    
    if original_text and selected_language:
        translated_text = translate_text(original_text, selected_language)
    else:
        translated_text = original_text

    return jsonify({
        "original": original_text,
        "translated": translated_text,
        "language": selected_language
    })

def translate_text(text, target_lang):
    """Translates text using MyMemory API."""
    params = {"q": text, "langpair": f"en|{target_lang}"}
    response = requests.get(TRANSLATION_API_URL, params=params).json()
    
    return response.get("responseData", {}).get("translatedText", text)

@app.route('/match-result', methods=['POST'])
def update_match_result():
    """Updates the match result dynamically."""
    global match_data
    match_data = request.json  # Receive JSON data from the client
    return jsonify({"status": "success", "message": "Match result updated!"})

if __name__ == '__main__':
    app.run(debug=True)
