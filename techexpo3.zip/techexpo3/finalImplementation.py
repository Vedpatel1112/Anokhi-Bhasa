from flask import Flask, render_template, Response, request, jsonify
from flask_cors import CORS
import cv2
import numpy as np
import mediapipe as mp
import os
import time
import threading
import requests
import re
 
app = Flask(__name__)
CORS(app)

# API for Translation
TRANSLATION_API_URL = "https://api.mymemory.translated.net/get"

# Directories
FOLDER = "captured_images"
COMPARISON_FOLDER = "check_image"
os.makedirs(FOLDER, exist_ok=True)
os.makedirs(COMPARISON_FOLDER, exist_ok=True)

# Initialize Variables
cap = cv2.VideoCapture(0)
camera_status = 'Start Webcam'
MATCH_DATA = {"matched_label": "No match found"}  # Store last match result

# MediaPipe & HandDetector
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=True, max_num_hands=1, min_detection_confidence=0.5)

# Function: Extract Hand Landmarks (Optimized)
def extract_hand_landmarks(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return None

    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    result = hands.process(image_rgb)

    if result.multi_hand_landmarks:
        return np.array([[lm.x, lm.y, lm.z] for lm in result.multi_hand_landmarks[0].landmark]).flatten()
    
    return None  # No hand detected

# Function: Calculate Similarity
def calculate_similarity(landmarks1, landmarks2):
    if landmarks1.shape != landmarks2.shape:
        return float('inf')
    return np.linalg.norm(landmarks1 - landmarks2)

# Function: Match Input Image to Database
def match_image(input_image):
    input_landmarks = extract_hand_landmarks(input_image)
    if input_landmarks is None:
        return None

    closest_match = None
    closest_distance = float('inf')

    for file_name in os.listdir(COMPARISON_FOLDER):
        file_path = os.path.join(COMPARISON_FOLDER, file_name)
        comparison_landmarks = extract_hand_landmarks(file_path)

        if comparison_landmarks is not None:
            distance = calculate_similarity(input_landmarks, comparison_landmarks)
            if distance < closest_distance:
                closest_distance = distance
                closest_match = re.sub(r'[ \[\] (){}0-9]', '', os.path.splitext(file_name)[0])

    if closest_match:
        with open("example.txt", "a") as file:
            file.write(closest_match + " ")

        MATCH_DATA["matched_label"] = closest_match
        return closest_match

    return None

# Function: Capture Image & Match (Optimized)
def capture_images_and_match():
    global MATCH_DATA
    success, img = cap.read()
    if not success:
        return None

    timestamp = str(time.time())
    captured_image_path = f"{FOLDER}/Image_{timestamp}.jpg"
    cv2.imwrite(captured_image_path, img)

    matched_label = match_image(captured_image_path)
    return matched_label

# Function: Webcam Video Feed (Optimized)
def video_feed():
    last_called_time = time.time()
    interval = 3  # Capture every 3 seconds

    while True:
        success, img = cap.read()
        if not success:
            break

        # Reduce processing frequency
        if time.time() - last_called_time >= interval:
            capture_images_and_match()
            last_called_time = time.time()

        _, buffer = cv2.imencode('.jpg', img)
        yield (b'--img\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

# Flask Routes
@app.route("/")
def index():
    return render_template("index.html", camera_status=camera_status)

@app.route('/toggle', methods=['POST'])
def toggle():
    global camera_status
    if camera_status == 'Start Webcam':
        threading.Thread(target=video_feed, daemon=True).start()
        camera_status = 'Stop Webcam'
    else:
        camera_status = 'Start Webcam'
    return render_template('index.html', camera_status=camera_status)

@app.route("/video_feed1")
def video_feed1():
    return Response(video_feed(), mimetype='multipart/x-mixed-replace; boundary=img')

@app.route('/match-result', methods=['GET'])
def get_match_result():
    selected_language = request.args.get("lang", "en")
    original_text = MATCH_DATA.get("matched_label", "No match found")
    translated_text = translate_text(original_text, selected_language)
    return jsonify({"original": original_text, "translated": translated_text, "language": selected_language})


def translate_text(text, target_lang):
    try:
        params = {"q": text, "langpair": f"en|{target_lang}"}
        response = requests.get(TRANSLATION_API_URL, params=params).json()
        return response.get("responseData", {}).get("translatedText", text)
    except Exception:
        return text

@app.route('/match-result', methods=['POST'])
def update_match_result():
    global MATCH_DATA
    MATCH_DATA = request.json
    return jsonify({"status": "success", "message": "Match result updated!"})

if __name__ == '__main__':
    app.run(debug=True)
